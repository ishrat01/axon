package sample.event;

/**
 * Created by ishratjahan on 29/03/17.
 */
public class CustomerPhoneNumberUpdatedEvent {
    private final String accountId;
    private long phoneNo;

    public CustomerPhoneNumberUpdatedEvent(String accountId, long phoneNo) {
        this.accountId = accountId;
        this.phoneNo=phoneNo;
    }

    public String getAccountNo() {
        return accountId;
    }

    public long hetPhoneNo() {
        return phoneNo;
    }

    public long getPhoneNo() {
        return phoneNo;
    }
}
