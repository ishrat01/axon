package sample.event;

/**
 * Created by ishratjahan on 29/03/17.
 */
public class CustomerCreatedEvent {

    private final String accountId;
    private String name;
    private long phoneNo;
    private String address;

    public CustomerCreatedEvent(String accountId, String name, String address, long phoneNo) {
        this.accountId = accountId;
        this.name=name;
        this.phoneNo=phoneNo;
        this.address=address;
    }

    public String getAccountNo() {
        return accountId;
    }

    public String getName() {
        return name;
    }

    public long getPhoneNo() {
        return phoneNo;
    }

    public String getAddress() {
        return address;
    }
}
