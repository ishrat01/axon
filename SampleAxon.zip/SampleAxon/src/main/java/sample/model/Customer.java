package sample.model;


import org.axonframework.eventsourcing.annotation.AbstractAnnotatedAggregateRoot;
import org.axonframework.eventsourcing.annotation.AggregateIdentifier;
import org.axonframework.eventsourcing.annotation.EventSourcingHandler;
import sample.event.CustomerCreatedEvent;
import sample.event.CustomerPhoneNumberUpdatedEvent;

/**
 * Created by ishratjahan on 29/03/17.
 */
public class Customer extends AbstractAnnotatedAggregateRoot
{
    @AggregateIdentifier
    private String accountId;
    private long phoneNo;
    private String name;
    private String address;

    public Customer() {
    }

    public Customer(String accountNo) {

        apply(new CustomerCreatedEvent(accountId,name,address,phoneNo));
    }

    public Customer(long phoneNo, String name, String address) {
        this.accountId=name+phoneNo;
        this.phoneNo = phoneNo;
        this.name = name;
        this.address = address;
    }

    public void create(){
        apply(new CustomerCreatedEvent(this.accountId,this.getName(),this.getAddress(),this.getPhoneNo()));
    }

    @EventSourcingHandler
    public void applyAccountCreation(CustomerCreatedEvent customerAccountCreatedEvent) {
        this.accountId = customerAccountCreatedEvent.getAccountNo();
        this.phoneNo=customerAccountCreatedEvent.getPhoneNo();
        this.name=customerAccountCreatedEvent.getName();
        this.address=customerAccountCreatedEvent.getAddress();
    }

    @EventSourcingHandler
    public void applyPhoneNoUpdate(CustomerPhoneNumberUpdatedEvent customerPhoneNoUpdatedEvent)
    {
        this.phoneNo=customerPhoneNoUpdatedEvent.getPhoneNo();
    }

    public void updatePhoneNumber(long phoneNo)
    {
        apply(new CustomerPhoneNumberUpdatedEvent(this.accountId,phoneNo));
    }

    @Override
    public Object getIdentifier() {
        return accountId;
    }

    public String getAccountId() {
        return accountId;
    }

    public long getPhoneNo() {
        return phoneNo;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }
}
