package sample.commandHandler;

import org.axonframework.commandhandling.annotation.CommandHandler;
import org.axonframework.repository.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import sample.command.CreateCustomerCommand;
import sample.model.Customer;

/**
 * Created by ishratjahan on 29/03/17.
 */
public class CreateCustomerCommandHandler {

    Repository repository;

    @Autowired
    public CreateCustomerCommandHandler(Repository repository) {
        this.repository = repository;
    }

    @CommandHandler
    public void handle(CreateCustomerCommand createCustomerCommand){
        Customer customer=new Customer(createCustomerCommand.getPhoneNo(),createCustomerCommand.getName(),createCustomerCommand.getAddress());
        repository.add(customer);
        customer.create();
    }
}
