$(function() {

    // create customer
    $("#create").on("click", function() {
        var name = $("#name").val();
        var phone = $("#phone").val();
        var address = $("#address").val();

        $.ajax({
            url: "/create",
            method: "GET",
            data: {"name": name,"phone":phone, "address":address},
            success: function(a) {
                $("#name").val("");
                $("#phone").val("");
                $("#address").val("");
            },
            error: function(a) {
                console.log(a);
            }
        })
    });

    //update
    $("#update").on("click", function() {
        var accountId = $("#accountid").val();
        var phone = $("#phone").val();

        $.ajax({
            url: "/update",
            method: "GET",
            data: {"accountId": accountId,"phone":phone},
            success: function(a) {
                $("#accountid").val("");
                $("#phone").val("");
            },
            error: function(a) {
                console.log(a);
            }
        })
    });

});