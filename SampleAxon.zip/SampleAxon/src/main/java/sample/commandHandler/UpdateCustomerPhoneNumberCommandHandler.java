package sample.commandHandler;

import org.axonframework.commandhandling.annotation.CommandHandler;
import org.axonframework.repository.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import sample.command.UpdateCustomerPhoneNumberCommand;
import sample.model.Customer;

/**
 * Created by ishratjahan on 29/03/17.
 */

public class UpdateCustomerPhoneNumberCommandHandler {
    Repository repository;

    @Autowired
    public UpdateCustomerPhoneNumberCommandHandler(Repository repository) {
        this.repository = repository;
    }

    @CommandHandler
    public void handle(UpdateCustomerPhoneNumberCommand updateCustomerPhoneNumberCommand)
    {
        Customer customer=(Customer)repository.load(updateCustomerPhoneNumberCommand.getAccountId());
        //repository.add(customer);
        customer.updatePhoneNumber(updateCustomerPhoneNumberCommand.getPhoneNo());
    }
}
