package sample.eventHandler;

import org.axonframework.eventhandling.annotation.EventHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import sample.event.CustomerPhoneNumberUpdatedEvent;

import javax.sql.DataSource;

/**
 * Created by ishratjahan on 29/03/17.
 */
public class CustomerPhoneNumberUpdatedEventHandler {
    @Autowired
    DataSource dataSource;

    @EventHandler
    public void handleUpdateCustomerCommand(CustomerPhoneNumberUpdatedEvent event) {
        JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);

        String accountId = event.getAccountNo();
        long phoneNo = event.getPhoneNo();


        String updateQuery = "UPDATE customer SET phoneNo=? WHERE accountId=?";
        jdbcTemplate.update(updateQuery,phoneNo,accountId);

    }

}
