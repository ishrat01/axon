package sample;

import org.axonframework.commandhandling.CommandBus;
import org.axonframework.commandhandling.SimpleCommandBus;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.commandhandling.gateway.DefaultCommandGateway;
import org.axonframework.contextsupport.spring.AnnotationDriven;
import org.axonframework.domain.EventMessage;
import org.axonframework.eventhandling.Cluster;
import org.axonframework.eventhandling.EventBus;
import org.axonframework.eventhandling.EventBusTerminal;
import org.axonframework.eventhandling.SimpleEventBus;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.axonframework.eventstore.EventStore;
import org.axonframework.eventstore.fs.FileSystemEventStore;
import org.axonframework.eventstore.fs.SimpleEventFileResolver;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import sample.model.Customer;

import javax.sql.DataSource;
import java.io.File;

/**
 * Created by ishratjahan on 30/03/17.
 */

@Configuration
@AnnotationDriven
public class AppConfiguration {

    @Bean
    public DataSource dataSource() {
        return DataSourceBuilder
                .create()
                .username("root")
                .password("root")
                .url("jdbc:mysql://localhost:8889/sampleaxon")
                .driverClassName("com.mysql.jdbc.Driver")
                .build();
    }

    @Bean
    public EventSourcingRepository taskRepository() {
        FileSystemEventStore eventStore = (FileSystemEventStore) fileSystemEventStore();
        EventSourcingRepository repository = new EventSourcingRepository(Customer.class, eventStore);
        repository.setEventBus(eventBus());
        return repository;
    }

    @Bean
    public EventStore fileSystemEventStore()
    {
        return new FileSystemEventStore(new SimpleEventFileResolver(new File("data/evenstore")));
    }

    @Bean
    public CommandBus commandBus() {
        SimpleCommandBus simpleCommandBus = new SimpleCommandBus();
        return simpleCommandBus;
    }

    @Bean
    public EventBus eventBus() {
        return new SimpleEventBus();
    }

    @Bean
    public EventBusTerminal terminal() {
        return new EventBusTerminal() {
            public void publish(EventMessage... events) {
                eventBus().publish(events);
            }
            public void onClusterCreated(Cluster cluster) {

            }
        };
    }

    @Bean("commandGateway")
    public CommandGateway commandGateway() {
        return new DefaultCommandGateway(commandBus());
    }
}
