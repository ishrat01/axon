package sample.command;

/**
 * Created by ishratjahan on 29/03/17.
 */
public class CreateCustomerCommand {

    private String name;
    private long phoneNo;
    private String address;

    public CreateCustomerCommand (String name, long phoneNo, String address) {
        this.name = name;
        this.phoneNo = phoneNo;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public long getPhoneNo() {
        return phoneNo;
    }

    public String getAddress() {
        return address;
    }
}
