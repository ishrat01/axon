package sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Created by ishratjahan on 30/03/17.
 */
@SpringBootApplication
@ComponentScan
public class SampleAxon {

    public static void main(String[] args) {
        SpringApplication.run(SampleAxon.class, args);
    }
}
