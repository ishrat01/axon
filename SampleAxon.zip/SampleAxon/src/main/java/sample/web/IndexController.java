package sample.web;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import sample.command.CreateCustomerCommand;
import sample.command.UpdateCustomerPhoneNumberCommand;

/**
 * Created by ishratjahan on 30/03/17.
 */
@Controller
public class IndexController {

    @Autowired
    @Qualifier("commandGateway")
    private CommandGateway commandGateway;

    @RequestMapping("/index")
    public String index() {
        return "index";
    }

    @RequestMapping("/createpage")
    public String create() {
        return "createpage";
    }

    @RequestMapping("/updatepage")
    public String update() {
        return "updatepage";
    }

    @RequestMapping(value = "/create",method = RequestMethod.POST)
    @Transactional
    @ResponseBody
    public void createCustomer(@RequestParam("name") String name, @RequestParam("phone") long phone,@RequestParam("address") String address) {
        CreateCustomerCommand createCustomerCommand = new CreateCustomerCommand(name,phone,address);
        commandGateway.send(createCustomerCommand);
    }

    @RequestMapping(value = "/update",method = RequestMethod.POST)
    @Transactional
    @ResponseBody
    public void updateCusatomer(@RequestParam("accountId") String accountId, @RequestParam("phone") long phone) {
        UpdateCustomerPhoneNumberCommand updateCustomerPhoneNumberCommand = new UpdateCustomerPhoneNumberCommand(accountId,phone);
        commandGateway.send(updateCustomerPhoneNumberCommand);
    }
}
