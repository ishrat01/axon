package sample.command;

/**
 * Created by ishratjahan on 29/03/17.
 */
public class UpdateCustomerPhoneNumberCommand {

    private String accountId;
    private long phoneNo;

    public UpdateCustomerPhoneNumberCommand(String accountId, long phoneNo) {
        this.accountId = accountId;
        this.phoneNo = phoneNo;
    }

    public String getAccountId() {
        return accountId;
    }

    public long getPhoneNo() {
        return phoneNo;
    }
}
