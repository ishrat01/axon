package sample.eventHandler;

import org.axonframework.eventhandling.annotation.EventHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import sample.event.CustomerCreatedEvent;

import javax.sql.DataSource;

/**
 * Created by ishratjahan on 29/03/17.
 */
public class CustomerCreatedEventHandler {
    @Autowired
    DataSource dataSource;

    @EventHandler
    public void handleCustomerCreatedEvent(CustomerCreatedEvent event) {
        JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);

        String accountId = event.getAccountNo();
        String name = event.getName();
        long phoneNo = event.getPhoneNo();
        String address = event.getAddress();

        // Update the view
        String createQuery = "INSERT into customer values(?, ?, ?, ?)";
        jdbcTemplate.update(createQuery,accountId,name,phoneNo,address);

    }
    }
